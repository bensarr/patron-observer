package dp_observer;

public interface Observer {
	public void update(Observable observable);//pull: Observable || push: state
}
